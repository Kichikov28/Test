﻿using System;

namespace P13_CryptoMiningSystem
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
        }
    }
}
